/**
 * @file calculator.cpp
 * @brief Modern C++ Scientific Calculator Application
 * 
 * Features:
 * - Full arithmetic expression parsing with correct precedence and associativity
 * - Support for standard operators: +, -, *, /, %, ^ (exponentiation)
 * - Scientific math functions: sin, cos, tan, asin, acos, atan, atan2,
 *   sinh, cosh, tanh, sqrt, cbrt, abs, ln, log (base 10), log2, exp,
 *   floor, ceil, round, deg, rad, min, max, hypot
 * - Mathematical constants: pi, e, phi, tau
 * - Interactive REPL with command history and variable assignment (e.g. x = 42, area = pi * r^2)
 * - Automatic previous result tracking with 'ans'
 * - Direct command-line evaluation (e.g. ./calculator "2 * (3 + 4)^2")
 * - Automated self-test suite (--test)
 * - Robust error handling for syntax errors, division by zero, and domain errors
 */

#include <iostream>
#include <string>
#include <vector>
#include <map>
#include <cmath>
#include <cctype>
#include <sstream>
#include <iomanip>
#include <stdexcept>
#include <cassert>
#include <functional>
#include <algorithm>

namespace calc {

// Mathematical constants
constexpr double PI   = 3.14159265358979323846;
constexpr double E    = 2.71828182845904523536;
constexpr double PHI  = 1.61803398874989484820;
constexpr double TAU  = 6.28318530717958647692;

/**
 * @brief Custom exception for calculation and syntax errors
 */
class CalculatorError : public std::runtime_error {
public:
    explicit CalculatorError(const std::string& message, size_t pos = 0)
        : std::runtime_error(message), position_(pos) {}
    
    size_t position() const { return position_; }
private:
    size_t position_;
};

enum class TokenType {
    Number,
    Identifier,
    Plus,
    Minus,
    Star,
    Slash,
    Percent,
    Caret,
    LParen,
    RParen,
    Comma,
    Equals,
    EndOfInput
};

struct Token {
    TokenType type;
    std::string text;
    double numberValue = 0.0;
    size_t position = 0;
};

/**
 * @brief Tokenizer / Lexer for arithmetic expressions
 */
class Lexer {
public:
    explicit Lexer(std::string src) : source_(std::move(src)), cursor_(0) {}

    std::vector<Token> tokenize() {
        std::vector<Token> tokens;
        while (cursor_ < source_.size()) {
            char ch = source_[cursor_];

            if (std::isspace(static_cast<unsigned char>(ch))) {
                cursor_++;
                continue;
            }

            size_t startPos = cursor_;

            if (std::isdigit(static_cast<unsigned char>(ch)) || (ch == '.' && hasDigitAfterDot())) {
                tokens.push_back(lexNumber());
            } else if (std::isalpha(static_cast<unsigned char>(ch)) || ch == '_') {
                tokens.push_back(lexIdentifier());
            } else {
                tokens.push_back(lexSymbol(startPos));
            }
        }

        tokens.push_back({TokenType::EndOfInput, "<EOF>", 0.0, cursor_});
        return tokens;
    }

private:
    std::string source_;
    size_t cursor_;

    bool hasDigitAfterDot() const {
        return (cursor_ + 1 < source_.size() && std::isdigit(static_cast<unsigned char>(source_[cursor_ + 1])));
    }

    Token lexNumber() {
        size_t start = cursor_;
        bool dotSeen = false;
        bool expSeen = false;

        while (cursor_ < source_.size()) {
            char c = source_[cursor_];
            if (std::isdigit(static_cast<unsigned char>(c))) {
                cursor_++;
            } else if (c == '.' && !dotSeen && !expSeen) {
                dotSeen = true;
                cursor_++;
            } else if ((c == 'e' || c == 'E') && !expSeen) {
                expSeen = true;
                cursor_++;
                if (cursor_ < source_.size() && (source_[cursor_] == '+' || source_[cursor_] == '-')) {
                    cursor_++;
                }
            } else {
                break;
            }
        }

        std::string numStr = source_.substr(start, cursor_ - start);
        double val = 0.0;
        try {
            val = std::stod(numStr);
        } catch (const std::exception&) {
            throw CalculatorError("Invalid floating-point number: '" + numStr + "'", start);
        }

        return {TokenType::Number, numStr, val, start};
    }

    Token lexIdentifier() {
        size_t start = cursor_;
        while (cursor_ < source_.size() && 
              (std::isalnum(static_cast<unsigned char>(source_[cursor_])) || source_[cursor_] == '_')) {
            cursor_++;
        }
        std::string name = source_.substr(start, cursor_ - start);
        // Case-insensitive identifiers for functions/constants
        std::string lowerName = name;
        std::transform(lowerName.begin(), lowerName.end(), lowerName.begin(),
                       [](unsigned char c){ return std::tolower(c); });

        return {TokenType::Identifier, lowerName, 0.0, start};
    }

    Token lexSymbol(size_t start) {
        char ch = source_[cursor_++];
        switch (ch) {
            case '+': return {TokenType::Plus, "+", 0.0, start};
            case '-': return {TokenType::Minus, "-", 0.0, start};
            case '*': return {TokenType::Star, "*", 0.0, start};
            case '/': return {TokenType::Slash, "/", 0.0, start};
            case '%': return {TokenType::Percent, "%", 0.0, start};
            case '^': return {TokenType::Caret, "^", 0.0, start};
            case '(': return {TokenType::LParen, "(", 0.0, start};
            case ')': return {TokenType::RParen, ")", 0.0, start};
            case ',': return {TokenType::Comma, ",", 0.0, start};
            case '=': return {TokenType::Equals, "=", 0.0, start};
            default:
                throw CalculatorError(std::string("Unexpected character: '") + ch + "'", start);
        }
    }
};

/**
 * @brief Core Calculator Engine evaluating expressions and maintaining variables
 */
class Calculator {
public:
    Calculator() {
        resetVariables();
    }

    void resetVariables() {
        variables_.clear();
        variables_["pi"]  = PI;
        variables_["e"]   = E;
        variables_["phi"] = PHI;
        variables_["tau"] = TAU;
        variables_["ans"] = 0.0;
    }

    void setVariable(const std::string& name, double value) {
        std::string lower = name;
        std::transform(lower.begin(), lower.end(), lower.begin(),
                       [](unsigned char c){ return std::tolower(c); });
        variables_[lower] = value;
    }

    double getVariable(const std::string& name) const {
        std::string lower = name;
        std::transform(lower.begin(), lower.end(), lower.begin(),
                       [](unsigned char c){ return std::tolower(c); });
        auto it = variables_.find(lower);
        if (it != variables_.end()) {
            return it->second;
        }
        throw CalculatorError("Undefined variable: '" + name + "'");
    }

    const std::map<std::string, double>& variables() const {
        return variables_;
    }

    /**
     * @brief Parses and evaluates a single statement (assignment or expression)
     */
    double evaluate(const std::string& input) {
        if (input.empty()) return 0.0;

        Lexer lexer(input);
        tokens_ = lexer.tokenize();
        tokenIndex_ = 0;

        if (peek().type == TokenType::EndOfInput) {
            return 0.0;
        }

        // Check if top-level assignment: IDENTIFIER '=' <expression>
        if (peek().type == TokenType::Identifier && 
            peekAhead(1).type == TokenType::Equals) {
            std::string varName = peek().text;
            consume(TokenType::Identifier);
            consume(TokenType::Equals);

            double val = parseExpression();
            if (peek().type != TokenType::EndOfInput) {
                throw CalculatorError("Unexpected token after expression: '" + peek().text + "'", peek().position);
            }
            setVariable(varName, val);
            setVariable("ans", val);
            return val;
        }

        double result = parseExpression();
        if (peek().type != TokenType::EndOfInput) {
            throw CalculatorError("Unexpected token after expression: '" + peek().text + "'", peek().position);
        }
        setVariable("ans", result);
        return result;
    }

    /**
     * @brief Run verification self-tests
     */
    static void runTests() {
        std::cout << "Running Calculator Automated Test Suite...\n";
        Calculator calc;
        size_t passed = 0;
        size_t total = 0;

        auto testExpr = [&](const std::string& expr, double expected, double tolerance = 1e-6) {
            total++;
            try {
                double res = calc.evaluate(expr);
                if (std::abs(res - expected) <= tolerance) {
                    passed++;
                } else {
                    std::cerr << "[-] FAILED: \"" << expr << "\" Expected: " 
                              << expected << ", Got: " << res << "\n";
                }
            } catch (const std::exception& e) {
                std::cerr << "[-] EXCEPTION in \"" << expr << "\": " << e.what() << "\n";
            }
        };

        auto testThrows = [&](const std::string& expr) {
            total++;
            try {
                calc.evaluate(expr);
                std::cerr << "[-] FAILED: Expected exception for: \"" << expr << "\"\n";
            } catch (const CalculatorError&) {
                passed++;
            } catch (const std::exception& e) {
                std::cerr << "[-] UNEXPECTED EXCEPTION for \"" << expr << "\": " << e.what() << "\n";
            }
        };

        // Basic arithmetic & precedence
        testExpr("1 + 2", 3.0);
        testExpr("10 - 4", 6.0);
        testExpr("2 * 3 + 4", 10.0);
        testExpr("2 + 3 * 4", 14.0);
        testExpr("(2 + 3) * 4", 20.0);
        testExpr("100 / 4 / 5", 5.0);
        testExpr("17 % 5", 2.0);

        // Unary minus & plus
        testExpr("-5 + 8", 3.0);
        testExpr("+7 * -2", -14.0);
        testExpr("-(3 + 4)", -7.0);

        // Power operator (right-associative)
        testExpr("2 ^ 3", 8.0);
        testExpr("2 ^ 3 ^ 2", 512.0); // 2^(3^2) = 2^9 = 512
        testExpr("4 ^ 0.5", 2.0);
        testExpr("2 ^ -1", 0.5);

        // Constants & Functions
        testExpr("pi", PI);
        testExpr("e", E);
        testExpr("sin(0)", 0.0);
        testExpr("cos(0)", 1.0);
        testExpr("sin(pi / 2)", 1.0);
        testExpr("sqrt(144)", 12.0);
        testExpr("cbrt(27)", 3.0);
        testExpr("abs(-42.5)", 42.5);
        testExpr("ln(e)", 1.0);
        testExpr("log(1000)", 3.0);
        testExpr("log2(16)", 4.0);
        testExpr("exp(0)", 1.0);
        testExpr("floor(3.8)", 3.0);
        testExpr("ceil(3.2)", 4.0);
        testExpr("round(3.5)", 4.0);
        testExpr("min(10, 25)", 10.0);
        testExpr("max(10, 25)", 25.0);
        testExpr("hypot(3, 4)", 5.0);
        testExpr("deg(pi)", 180.0);
        testExpr("rad(180)", PI);

        // Variables and assignments
        testExpr("x = 15", 15.0);
        testExpr("y = 5", 5.0);
        testExpr("x + y * 2", 25.0);
        testExpr("ans", 25.0);
        testExpr("ans / 5", 5.0);
        testExpr("ans", 5.0);

        // Errors & exception handling
        testThrows("10 / 0");
        testThrows("10 % 0");
        testThrows("sqrt(-4)");
        testThrows("ln(-1)");
        testThrows("log(0)");
        testThrows("asin(2)");
        testThrows("acos(-1.5)");
        testThrows("unknown_var + 1");
        testThrows("(2 + 3");
        testThrows("2 + +");

        std::cout << "Test Results: " << passed << " / " << total << " tests passed (" 
                  << (passed == total ? "ALL PASSED" : "SOME FAILED") << ").\n";
        assert(passed == total && "All test cases must pass!");
    }

private:
    std::map<std::string, double> variables_;
    std::vector<Token> tokens_;
    size_t tokenIndex_ = 0;

    const Token& peek() const {
        if (tokenIndex_ < tokens_.size()) return tokens_[tokenIndex_];
        return tokens_.back();
    }

    const Token& peekAhead(size_t offset) const {
        if (tokenIndex_ + offset < tokens_.size()) return tokens_[tokenIndex_ + offset];
        return tokens_.back();
    }

    Token consume(TokenType expected) {
        if (peek().type == expected) {
            return tokens_[tokenIndex_++];
        }
        throw CalculatorError("Expected token type " + std::to_string(static_cast<int>(expected)) + 
                              " but got '" + peek().text + "'", peek().position);
    }

    // Grammar:
    // expression := term (('+' | '-') term)*
    // term       := unary (('*' | '/' | '%') unary)*
    // unary      := ('+' | '-') unary | power
    // power      := primary ('^' unary)?
    // primary    := NUMBER | IDENTIFIER '(' arguments ')' | IDENTIFIER | '(' expression ')'

    double parseExpression() {
        double result = parseTerm();
        while (peek().type == TokenType::Plus || peek().type == TokenType::Minus) {
            TokenType op = peek().type;
            tokenIndex_++;
            double rhs = parseTerm();
            if (op == TokenType::Plus) {
                result += rhs;
            } else {
                result -= rhs;
            }
        }
        return result;
    }

    double parseTerm() {
        double result = parseUnary();
        while (peek().type == TokenType::Star || 
               peek().type == TokenType::Slash || 
               peek().type == TokenType::Percent) {
            TokenType op = peek().type;
            size_t pos = peek().position;
            tokenIndex_++;
            double rhs = parseUnary();

            if (op == TokenType::Star) {
                result *= rhs;
            } else if (op == TokenType::Slash) {
                if (rhs == 0.0) {
                    throw CalculatorError("Division by zero", pos);
                }
                result /= rhs;
            } else if (op == TokenType::Percent) {
                if (rhs == 0.0) {
                    throw CalculatorError("Modulo by zero", pos);
                }
                result = std::fmod(result, rhs);
            }
        }
        return result;
    }

    double parseUnary() {
        if (peek().type == TokenType::Plus) {
            tokenIndex_++;
            return parseUnary();
        }
        if (peek().type == TokenType::Minus) {
            tokenIndex_++;
            return -parseUnary();
        }
        return parsePower();
    }

    double parsePower() {
        double base = parsePrimary();
        if (peek().type == TokenType::Caret) {
            size_t pos = peek().position;
            tokenIndex_++;
            // Right-associative exponentiation: 2^3^2 = 2^(3^2)
            double exponent = parseUnary();
            if (base < 0.0 && std::floor(exponent) != exponent) {
                throw CalculatorError("Negative base with non-integer exponent", pos);
            }
            return std::pow(base, exponent);
        }
        return base;
    }

    double parsePrimary() {
        const Token& tok = peek();

        if (tok.type == TokenType::Number) {
            tokenIndex_++;
            return tok.numberValue;
        }

        if (tok.type == TokenType::LParen) {
            tokenIndex_++;
            double val = parseExpression();
            if (peek().type != TokenType::RParen) {
                throw CalculatorError("Mismatched parentheses: expected ')'", peek().position);
            }
            tokenIndex_++;
            return val;
        }

        if (tok.type == TokenType::Identifier) {
            std::string name = tok.text;
            size_t pos = tok.position;
            tokenIndex_++;

            // Function call: identifier '(' args ')'
            if (peek().type == TokenType::LParen) {
                tokenIndex_++;
                std::vector<double> args;
                if (peek().type != TokenType::RParen) {
                    args.push_back(parseExpression());
                    while (peek().type == TokenType::Comma) {
                        tokenIndex_++;
                        args.push_back(parseExpression());
                    }
                }
                if (peek().type != TokenType::RParen) {
                    throw CalculatorError("Expected ')' closing function call for '" + name + "'", peek().position);
                }
                tokenIndex_++;
                return evaluateFunction(name, args, pos);
            }

            // Variable or constant lookup
            return getVariable(name);
        }

        throw CalculatorError("Unexpected token in expression: '" + tok.text + "'", tok.position);
    }

    double evaluateFunction(const std::string& name, const std::vector<double>& args, size_t pos) {
        auto checkArgCount = [&](size_t expected) {
            if (args.size() != expected) {
                throw CalculatorError("Function '" + name + "' expects " + std::to_string(expected) + 
                                      " arguments, got " + std::to_string(args.size()), pos);
            }
        };

        if (name == "sin")   { checkArgCount(1); return std::sin(args[0]); }
        if (name == "cos")   { checkArgCount(1); return std::cos(args[0]); }
        if (name == "tan")   { checkArgCount(1); return std::tan(args[0]); }
        if (name == "sinh")  { checkArgCount(1); return std::sinh(args[0]); }
        if (name == "cosh")  { checkArgCount(1); return std::cosh(args[0]); }
        if (name == "tanh")  { checkArgCount(1); return std::tanh(args[0]); }
        if (name == "asin")  { 
            checkArgCount(1); 
            if (args[0] < -1.0 || args[0] > 1.0) throw CalculatorError("asin domain error: argument must be in [-1, 1]", pos);
            return std::asin(args[0]); 
        }
        if (name == "acos")  { 
            checkArgCount(1); 
            if (args[0] < -1.0 || args[0] > 1.0) throw CalculatorError("acos domain error: argument must be in [-1, 1]", pos);
            return std::acos(args[0]); 
        }
        if (name == "atan")  { checkArgCount(1); return std::atan(args[0]); }
        if (name == "atan2") { checkArgCount(2); return std::atan2(args[0], args[1]); }
        if (name == "sqrt")  { 
            checkArgCount(1); 
            if (args[0] < 0.0) throw CalculatorError("Square root of negative number: " + std::to_string(args[0]), pos);
            return std::sqrt(args[0]); 
        }
        if (name == "cbrt")  { checkArgCount(1); return std::cbrt(args[0]); }
        if (name == "abs" || name == "fabs") { checkArgCount(1); return std::abs(args[0]); }
        if (name == "ln")    { 
            checkArgCount(1); 
            if (args[0] <= 0.0) throw CalculatorError("ln domain error: argument must be > 0", pos);
            return std::log(args[0]); 
        }
        if (name == "log")   { 
            checkArgCount(1); 
            if (args[0] <= 0.0) throw CalculatorError("log domain error: argument must be > 0", pos);
            return std::log10(args[0]); 
        }
        if (name == "log2")  { 
            checkArgCount(1); 
            if (args[0] <= 0.0) throw CalculatorError("log2 domain error: argument must be > 0", pos);
            return std::log2(args[0]); 
        }
        if (name == "exp")   { checkArgCount(1); return std::exp(args[0]); }
        if (name == "floor") { checkArgCount(1); return std::floor(args[0]); }
        if (name == "ceil")  { checkArgCount(1); return std::ceil(args[0]); }
        if (name == "round") { checkArgCount(1); return std::round(args[0]); }
        if (name == "deg")   { checkArgCount(1); return args[0] * (180.0 / PI); }
        if (name == "rad")   { checkArgCount(1); return args[0] * (PI / 180.0); }
        if (name == "pow")   { checkArgCount(2); return std::pow(args[0], args[1]); }
        if (name == "min")   { checkArgCount(2); return std::min(args[0], args[1]); }
        if (name == "max")   { checkArgCount(2); return std::max(args[0], args[1]); }
        if (name == "hypot") { checkArgCount(2); return std::hypot(args[0], args[1]); }

        throw CalculatorError("Unknown function: '" + name + "'", pos);
    }
};

} // namespace calc

void printHelp() {
    std::cout << "\n================ Scientific Calculator ================\n"
              << "Operations:\n"
              << "  +   Addition             -   Subtraction\n"
              << "  *   Multiplication       /   Division\n"
              << "  %   Modulo               ^   Exponentiation (power)\n"
              << "  ()  Parentheses groupings\n\n"
              << "Functions:\n"
              << "  Trigonometry: sin, cos, tan, asin, acos, atan, atan2(y, x)\n"
              << "  Hyperbolic:   sinh, cosh, tanh\n"
              << "  Exponential:  exp, ln (base e), log (base 10), log2 (base 2)\n"
              << "  Roots/Powers: sqrt, cbrt, pow(base, exp), hypot(a, b)\n"
              << "  Rounding:     round, floor, ceil, abs\n"
              << "  Conversions:  deg (rad->deg), rad (deg->rad)\n"
              << "  Min/Max:      min(a, b), max(a, b)\n\n"
              << "Constants:\n"
              << "  pi  (3.14159...)    e   (2.71828...)\n"
              << "  phi (1.61803...)    tau (6.28318...)\n\n"
              << "Variables:\n"
              << "  var = expr    Assign expression to variable (e.g. radius = 5)\n"
              << "  ans           Automatically holds the result of the last calculation\n\n"
              << "Commands:\n"
              << "  help, ?       Display this guide\n"
              << "  vars          Display all defined variables and values\n"
              << "  clear         Reset user variables to defaults\n"
              << "  test          Run automated self-tests\n"
              << "  exit, quit    Exit the calculator\n"
              << "=======================================================\n\n";
}

int main(int argc, char* argv[]) {
    calc::Calculator calculator;

    // Command-line flag parsing
    if (argc > 1) {
        std::string arg = argv[1];
        if (arg == "--test" || arg == "-t") {
            calc::Calculator::runTests();
            return 0;
        }
        if (arg == "--help" || arg == "-h") {
            printHelp();
            return 0;
        }

        // Direct expression calculation via CLI arguments
        std::ostringstream exprStream;
        for (int i = 1; i < argc; ++i) {
            if (i > 1) exprStream << " ";
            exprStream << argv[i];
        }

        try {
            double result = calculator.evaluate(exprStream.str());
            std::cout << std::setprecision(12) << result << "\n";
            return 0;
        } catch (const calc::CalculatorError& err) {
            std::cerr << "Error: " << err.what() << "\n";
            return 1;
        }
    }

    // Interactive REPL Mode
    std::cout << "============================================\n"
              << "    Triage Scientific Calculator App        \n"
              << "    Type 'help' for instructions, 'exit' to quit\n"
              << "============================================\n\n";

    std::string line;
    while (true) {
        std::cout << "calc> ";
        if (!std::getline(std::cin, line)) {
            break;
        }

        // Trim leading and trailing whitespace
        size_t first = line.find_first_not_of(" \t\r\n");
        if (first == std::string::npos) continue;
        size_t last = line.find_last_not_of(" \t\r\n");
        std::string cmd = line.substr(first, last - first + 1);

        if (cmd == "exit" || cmd == "quit") {
            std::cout << "Goodbye!\n";
            break;
        } else if (cmd == "help" || cmd == "?") {
            printHelp();
        } else if (cmd == "vars") {
            std::cout << "\nCurrent Variables & Constants:\n";
            for (const auto& [name, val] : calculator.variables()) {
                std::cout << "  " << std::left << std::setw(8) << name << " = " << val << "\n";
            }
            std::cout << "\n";
        } else if (cmd == "clear") {
            calculator.resetVariables();
            std::cout << "Variables reset to defaults.\n";
        } else if (cmd == "test") {
            calc::Calculator::runTests();
        } else {
            try {
                double res = calculator.evaluate(cmd);
                std::cout << "= " << std::setprecision(12) << res << "\n";
            } catch (const calc::CalculatorError& err) {
                std::cerr << "Error at index " << err.position() << ": " << err.what() << "\n";
            } catch (const std::exception& err) {
                std::cerr << "Error: " << err.what() << "\n";
            }
        }
    }

    return 0;
}
