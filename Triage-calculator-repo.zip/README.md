# Triage Calculator

A modern, high-performance C++ scientific calculator application supporting full mathematical expressions, advanced functions, variable assignment, previous result recall, interactive REPL mode, and command-line evaluation.

## Features

- **Full Mathematical Expression Parser**: Evaluates complex expressions with correct operator precedence and associativity (e.g. `2 * (3 + 4)^2`).
- **Standard Operators**:
  - Addition (`+`), Subtraction (`-`)
  - Multiplication (`*`), Division (`/`)
  - Modulo (`%`)
  - Exponentiation (`^`, right-associative: `2^3^2 = 512`)
- **Scientific Functions**:
  - *Trigonometric*: `sin`, `cos`, `tan`, `asin`, `acos`, `atan`, `atan2(y, x)`
  - *Hyperbolic*: `sinh`, `cosh`, `tanh`
  - *Exponential & Logarithmic*: `exp`, `ln` (base $e$), `log` (base 10), `log2` (base 2)
  - *Powers & Roots*: `sqrt`, `cbrt`, `pow(base, exp)`, `hypot(a, b)`
  - *Rounding & Utilities*: `abs`, `round`, `floor`, `ceil`, `min(a, b)`, `max(a, b)`
  - *Angle Conversion*: `deg` (radians to degrees), `rad` (degrees to radians)
- **Built-in Constants**:
  - `pi` (approx. 3.14159)
  - `e` (approx. 2.71828)
  - `phi` (approx. 1.61803)
  - `tau` (approx. 6.28318)
- **Variables & Memory**:
  - Store values: `r = 5`, `area = pi * r^2`
  - Automatic recall of last evaluated answer with `ans`
  - View defined variables with `vars` command
  - Reset variables with `clear` command
- **Interactive REPL & CLI Evaluation**:
  - Run interactively with prompt `calc> `
  - Evaluate directly from command line: `./calculator "2 * (3 + 4)^2"`
- **Robust Error Handling**:
  - Precise error reporting for division by zero, mismatched parentheses, invalid syntax, and mathematical domain errors (e.g., negative square roots).
- **Automated Self-Test Suite**:
  - Built-in test suite covering 50+ unit test assertions (`./calculator --test`).

## Building the Project

### Prerequisites
- C++17 compatible compiler (`g++` >= 7, `clang++` >= 5)
- `make` or `cmake` (>= 3.12)

### Build with Make
```bash
make
```

Run test suite:
```bash
make test
```

### Build with CMake
```bash
mkdir build && cd build
cmake ..
cmake --build .
ctest --output-on-failure
```

### Direct Compilation with g++
```bash
g++ -std=c++17 -Wall -Wextra -O2 calculator.cpp -o calculator
```

## Usage

### 1. Interactive Mode
Run `./calculator` without arguments:
```bash
$ ./calculator
============================================
    Triage Scientific Calculator App        
    Type 'help' for instructions, 'exit' to quit
============================================

calc> 2 + 3 * 4
= 14
calc> x = 10
= 10
calc> y = x * 2.5
= 25
calc> hypot(3, 4)
= 5
calc> sin(pi / 2)
= 1
calc> ans * 10
= 10
calc> vars

Current Variables & Constants:
  ans      = 10
  e        = 2.71828
  phi      = 1.61803
  pi       = 3.14159
  tau      = 6.28319
  x        = 10
  y        = 25

calc> exit
Goodbye!
```

### 2. Direct CLI Evaluation
Evaluate one-off expressions directly in your terminal:
```bash
$ ./calculator "2 * (3 + 4)^2"
98

$ ./calculator "sqrt(144) + log(1000)"
15
```

### 3. Automated Self-Tests
Verify parser and evaluation correctness:
```bash
$ ./calculator --test
Running Calculator Automated Test Suite...
Test Results: 50 / 50 tests passed (ALL PASSED).
```
